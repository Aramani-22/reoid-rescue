const admin = require('firebase-admin');
const fs = require('fs');

const serviceAccount = require('C:\\Users\\lenovo\\Downloads\\teamb-2b9c4-firebase-adminsdk-musrn-e1a325623e.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  storageBucket: 'gs://teamb-2b9c4.appspot.com',
});

const bucket = admin.storage().bucket();

async function uploadImage(filePath, originalFilename) {
  // Read the image file and convert it to a buffer
  const imageBuffer = fs.readFileSync(filePath);

  // Get the current date and time
  const currentDate = new Date();

  // Format the date as part of the new filename
  const formattedDate = currentDate.toISOString().replace(/[:.]/g, '-');

  // Create the new filename using the date
  const newFilename = `images/${formattedDate}_${originalFilename}`;

  // Upload the file to Firebase Storage
  await bucket.upload(imageBuffer, {
    destination: newFilename,
    metadata: {
      contentType: 'image/jpeg', // adjust the content type as needed
      metadata: {
        // You can also save the creation date in metadata
        creationDate: currentDate.toISOString(),
      },
    },
  });

  console.log(`Image uploaded with filename: ${newFilename}`);
}

// Usage example
const imagePath = 'C:/Users/lenovo/Desktop/Rapid Rescue/img/bg.png'; // Replace with the actual path to your image file
const originalFilename = 'bg.png'; // Replace with the actual filename
uploadImage(imagePath, originalFilename)
  .catch((error) => {
    console.error('Error uploading image:', error);
  });
